/*
 *  Matrix Task Processor
 *  Based on Operating Systems: Three Easy Pieces by R. Arpaci-Dusseau and A. Arpaci-Dusseau
 * 
 *  Assignment 3 code
 *  Program operates on tasks submitted to the tasks_input directory
 *  Results are created in the tasks_output directory
 *
 *  A bounded buffer is used to store pending tasks
 *  A producer thread reads tasks from the tasks_input directory 
 *  Consumer threads perform tasks in parallel
 *  Program is designed to run as a daemon (i.e. forever) until receiving a request to exit.
 *
 *  This program mimics the client/server processing model without the use of any networking constructs.
 *
 *  Wes J. Lloyd
 *  University of Washington, Tacoma
 *  TCSS 422 - Operating Systems
 *  Spring 2017
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include "matrix.h"
#include "tasks.h"
#include "pcmatrix.h"
#define NUMTHREADS 3 // number of threads for consumer

int main (int argc, char * argv[])
{

	// consumer array
	pthread_t * cons;
	//producer array
	pthread_t prod;
	//allocate memory for consumer
	cons = malloc(sizeof(pthread_t) * NUMTHREADS);
	//sleep 
	int sleep;
	//counter
	int i;
	
	// check argument
	if(argc == NULL){
		sleep = 500;
	} else {
		sleep = argc;
	}
  
  	//Create producer thread
     pthread_create(&prod, NULL, readtasks, (void*)&sleep);
     
     //Create consumer threads
  	for (i = 0; i < NUMTHREADS; i++){
  		pthread_create(&cons[i], NULL, dotasks, (void*)&sleep);
  	
  	}
  	
  	//Join 
  	 pthread_join(prod, NULL);
  	for (i = 0; i < NUMTHREADS; i++){
  		pthread_join(cons[i], NULL);
  	
  	}
 
  return 0;
}
