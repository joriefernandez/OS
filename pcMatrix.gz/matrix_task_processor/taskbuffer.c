/*
 *  TaskBuffer methods  for the bounded buffer
 * 
 *  Fernandez, Jorie
 *  Terikov, ALex
 *  TCSS 422 - Operating Systems
 *  Spring 2017
 */


#include <pthread.h>
#include "taskbuffer.h"
#define MAX 200

// character buffer
char * tasks[MAX];
//pointer to indicate next index to fill in
int fill_ptr = 0;
// pointer to indicate index to use
int use = 0;
//Current item count
int count = 0;
//Lock
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
//condition if empty
pthread_cond_t empty = PTHREAD_COND_INITIALIZER;
//condition if full
pthread_cond_t fill = PTHREAD_COND_INITIALIZER;

//Method to insert item in the buffer		
void put(char * theCopy){
 	pthread_mutex_lock(&mutex);
     while (count == MAX) {
            pthread_cond_wait(&empty, &mutex);
              		
      }
     
              
     tasks[fill_ptr] = strdup(theCopy);
	fill_ptr = (fill_ptr + 1) % MAX;
	count++;
 // First make a copy of the string in the buffer
		
		
	pthread_cond_signal(&fill);
	pthread_mutex_unlock(&mutex);
	
	
}

// Get item in the buffer
char * get() {

  // 

   pthread_mutex_lock(&mutex);
   while (count == 0) 
   	pthread_cond_wait(&fill, &mutex);
   	  
   char * val = tasks[use];
   use = (use + 1) % MAX;
   count--;
   pthread_cond_signal(&empty);
   pthread_mutex_unlock(&mutex);
   return val;
}

