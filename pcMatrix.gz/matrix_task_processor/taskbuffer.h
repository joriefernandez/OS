/*
 *  Library for the bounded buffer
 * 
 *  Fernandez, Jorie
 *  Terikov, ALex
 *  TCSS 422 - Operating Systems
 *  Spring 2017
 */

#ifndef _TASKBUFFER_H_
#define _TASKBUFFER_H_
	
	
void put(char * theCopy);
char * get();
	
#endif
